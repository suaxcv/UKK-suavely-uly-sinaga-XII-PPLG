<!DOCTYPE html>

<?php
    include 'koneksi.php';
    $query = "SELECT * FROM kategori;";
    $sql = mysqli_query($conn, $query);

    $no = 0;
?>
<html lang="en">
<head>
    <!-- BOOTSTRAP -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.bundle.min.js"></script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<nav class="navbar bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="logopolda.png" alt="Logo" width="60" height="45" class="d-inline-block align-text-top">
            Polresta padang
          </a>
        </div>
      </nav>

      <div class="container mt-3">
      <div class="table-responsive">
            <table class="table table-hover table-bordered border-light table-striped mt-3" id="example">
              <thead>
              <tr>
                <th class="table-dark">No</th>
                <th class="table-dark">ID kategori</th>
                <th class="table-dark">Kategori</th> 
              </tr>
              </thead>
              <tbody>
              <?php
               while ($result = mysqli_fetch_assoc($sql)) {
              ?>
              <tr>
                <td><?php echo ++$no ?></td>
                <td><?php echo $result['id_kategori']; ?></td>
                <td><?php echo $result['nama_kategori']; ?></td>
              </tr>
              <?php
               }
              ?>
              </tbody>
            </table>

              <a href="index.php" class="btn btn-primary">Home</a>
              <a href="kategori.php" class="btn btn-success">Form kategori</a>
      </div>
</body>
</html>
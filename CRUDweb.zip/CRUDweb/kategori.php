<!DOCTYPE html>

<?php
    include 'koneksi.php';
?>
<html lang="en">
<head>
    <!-- BOOTSTRAP -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.bundle.min.js"></script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<nav class="navbar bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="logopolda.png" alt="Logo" width="60" height="45" class="d-inline-block align-text-top">
            Polresta padang
          </a>
        </div>
      </nav>

      <div class="container mt-3">
        <form method="post" action="proses.php">
            <h2>Form Input Data Kategori</h2>
            <p>Silahkan isi data kategori dengan benar</p>
            <hr class="mb-4">
            
            <div class="mb-3 row">
                <label for="kategori" class="col-sm-2 col-form-label">Nama Kategori</label>
                <div class="col-sm-10">
                  <input required type="text" name="kategori" class="form-control" id="kategori" placeholder="Contoh: Makanan, Minuman, dll">
                </div>
              </div>
              
              <button type="submit" name="kategoris" value="add" class="btn btn-primary">Simpan</button>
              <a href="daftar.php" class="btn btn-success">Daftar kategori</a>
              <a href="index.php" class="btn btn-danger">Batal</a>
        </form>
      </div>
</body>
</html>
<?php
include 'koneksi.php';

session_start();

if(isset($_POST['kategoris'])){
    if($_POST['kategoris'] == "add"){
        $kategori = $_POST['kategori'];
        $query = "INSERT INTO kategori VALUES(null, '$kategori')";
        $sql = mysqli_query($conn, $query);

        if($sql){
            header("location: index.php");
        }
        else{
            echo $query;
        }
    } 
}


if(isset($_POST['aksi'])){
    if($_POST['aksi'] == "add"){
        $barang = $_POST['barang'];
        $kategori = $_POST['kategori'];
        $stok = $_POST['stok'];
        $harga = $_POST['harga'];
        $tanggal = $_POST['tanggal'];

        $query = "INSERT INTO barang VALUES(null, '$barang', '$kategori', '$stok', '$harga', '$tanggal')";
        $sql = mysqli_query($conn, $query);

        if($sql){
            $_SESSION['eksekusi'] = "Data berhasil ditambahkan";
            header("location: index.php");
        }
        else{
            echo $query;
        }

    } else if($_POST['aksi'] == "edit"){
        $id_barang = $_POST['id_barang'];
        $barang = $_POST['barang'];
        $kategori = $_POST['kategori'];
        $stok = $_POST['stok'];
        $harga = $_POST['harga'];
        $tanggal = $_POST['tanggal'];

        $query = "UPDATE barang SET nama_barang='$barang', kategori_barang='$kategori', jumlah_barang='$stok', harga_barang='$harga', tanggal_masuk='$tanggal' WHERE id_barang = '$id_barang';";
        $sql = mysqli_query($conn, $query);
        if($sql){
            $_SESSION['eksekusi'] = "Data berhasil diperbarui";
            header("location: index.php");
        }
        else{
            echo $query;
        } 

    }
}
    if(isset($_GET['hapus'])){
        $id_barang = $_GET['hapus'];
        $query = "DELETE FROM barang WHERE id_barang = '$id_barang';";
        $sql = mysqli_query($conn, $query);

        if($sql){
            $_SESSION['eksekusi'] = "Data berhasil dihapus";
            header("location: index.php");
        }
        else{
            echo $query;
        }
    }
?>
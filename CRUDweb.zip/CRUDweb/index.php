<?php
  include 'koneksi.php';
  session_start();
  
  $query = "SELECT * FROM barang;";
  $sql = mysqli_query($conn, $query);
  $no = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- BOOTSRAP -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.bundle.min.js"></script>
    <!-- DATA TABLES -->
    <link rel="stylesheet" type="text/css" href="datatables/datatables.css">
    <script type="text/javascript" src="datatables/datatables.js"></script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock barang</title>
</head>

<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable({
            "language": {
                "lengthMenu": "Tampilkan _MENU_ data per halaman",
                "zeroRecords": "Tidak ada data yang ditemukan",
                "info": "Menampilkan halaman _PAGE_ dari _PAGES_",
                "infoEmpty": "Tidak ada data yang tersedia",
                "infoFiltered": "(disaring dari _MAX_ total data)",
                "search": "Cari:",
                "paginate": {
                    "first":      "Pertama",
                    "last":       "Terakhir",
                    "next":       "Selanjutnya",
                    "previous":   "Sebelumnya"
                }
            }
        });
    });

  </script>

<body>
  <!-- Navbar -->
    <nav class="navbar bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="logopolda.png" alt="Logo" width="60" height="45" class="d-inline-block align-text-top">
            Polresta padang
          </a>
        </div>
      </nav>

      <div class="container mt-3">
        <figure>
            <blockquote class="blockquote">
              <p>Koperasi Polresta padang</p>
            </blockquote>
            <figcaption class="blockquote-footer">
              Polresta padang hebat! <cite title="Source Title">Polri untuk masyarakat</cite>
            </figcaption>
          </figure>

        <!-- button -->
        <a href="kelola.php" type="button" class="btn btn-outline-primary">Tambahkan data</a>
        <a href="kategori.php" type="button" class="btn btn-outline-success">Tambahkan Kategori</a>
        <a href="daftar.php" type="button" class="btn btn-outline-secondary">Daftar kategori</a>
        <!-- Alert -->
        <?php
            if (isset($_SESSION['eksekusi'])):
          ?>
          <div class="alert alert-success alert-dismissible fade show mt-3"role="alert">
            <strong> <?php echo $_SESSION['eksekusi']; ?> </strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php
            session_destroy();
            endif;
          ?>

        <!-- tabel -->
        <div class="table-responsive mt-3">
            <table class="table table-hover" id="example">
            <thead>
              <tr>
                <th class="table-dark">No</th>
                <th class="table-dark">ID Barang</th>
                <th class="table-dark">Nama Barang</th>
                <th class="table-dark">Id Kategori</th>
                <th class="table-dark">Jumlah Stock</th>
                <th class="table-dark">Harga Barang</th>
                <th class="table-dark">Tanggal Masuk</th>
                <th class="table-dark">Aksi</th>    
              </tr>
              </thead>
              <tbody>
              <?php
               while ($result = mysqli_fetch_assoc($sql)) {
              ?>
              <tr>
                <td><?php echo ++$no ?></td>
                <td><?php echo $result['Id_barang']; ?></td>
                <td><?php echo $result['nama_barang']; ?></td>
                <td><?php echo $result['kategori_barang']; ?></td>
                <td><?php echo $result['jumlah_barang']; ?></td>
                <td>Rp.<?php echo $result['harga_barang']; ?></td>
                <td><?php echo $result['tanggal_masuk']; ?></td>
                <td><a href="proses.php?hapus=<?php echo $result['Id_barang']; ?>" type="button" class="btn btn-outline-danger"onClick="return confirm('yakin mau hapus')">Hapus</a>
                    <a href="kelola.php?ubah=<?php echo $result['Id_barang']; ?>" type="button" class="btn btn-outline-warning">Edit</a>
                </td>
              </tr>
              <?php
               }
              ?>
              </tbody>
            </table>
          </div>
      </div>
</body>
</html>
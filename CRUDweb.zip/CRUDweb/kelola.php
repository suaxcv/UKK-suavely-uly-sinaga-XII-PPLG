<!DOCTYPE html>
<?php
  include'koneksi.php';
  session_start();

    $id_barang = '';
    $nama_barang = '';
    $kategori = '';
    $jumlah = '';
    $harga = '';
    $tanggal = '';

   if(isset($_GET['ubah'])){
    $id_barang = $_GET['ubah'];

    $query = "SELECT *FROM barang WHERE id_barang = '$id_barang';";
    $sql = mysqli_query($conn, $query);

    $result = mysqli_fetch_assoc($sql);

    $nama_barang = $result['nama_barang'];
    $kategori = $result['kategori_barang'];
    $jumlah = $result['jumlah_barang'];
    $harga = $result['harga_barang'];
    $tanggal = $result['tanggal_masuk'];


   }
?>
<html lang="en">
<head>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.bundle.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock barang</title>
</head>
<body>
    <nav class="navbar bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="logopolda.png" alt="Logo" width="60" height="45" class="d-inline-block align-text-top">
            Polresta padang
          </a>
        </div>
      </nav>

      <!-- form -->
      <div class="container mt-3">
        <form method="POST" action="proses.php">
         <input type="text" name="id_barang" value="<?php echo $id_barang ?>" hidden>
              <h2>Form Input Data Barang</h2>
              <p>Silahkan isi data barang dengan benar</p>
              <hr class="mb-4">
              
              <div class="mb-3 row">
                <label for="id_barang" class="col-sm-2 col-form-label">ID Barang</label>
                <div class="col-sm-10">
                  <input required type="text" name="id_barang" class="form-control" id="id_barang" placeholder="di isi otomatis" value="<?php echo $id_barang?>" readonly>
                </div>
              </div>

            <div class="mb-3 row">
                <label for="barang" class="col-sm-2 col-form-label">Nama Barang</label>
                <div class="col-sm-10">
                  <input required type="text" name="barang" class="form-control" id="barang" placeholder="milkita" value="<?php echo $nama_barang?>">
                </div>
              </div>
            
              <div class="mb-3 row">
                <label for="kategori" class="col-sm-2 col-form-label">Kategori Barang</label>
                <div class="col-sm-10">
                    <select required id="kategori" name="kategori" class="form-select">
                      <option value="">...</option>
                      <?php
                        $querys = mysqli_query($conn, "SELECT * FROM kategori;");
                        while($data = mysqli_fetch_assoc($querys)){
                          echo "<option value=$data[id_kategori]> $data[nama_kategori]</option>";
                        }
                      ?>
                    </select>
                </div>
              </div>
              <div class="mb-3 row">
                <label for="stok" class="col-sm-2 col-form-label">Stok Barang</label>
                <div class="col-sm-10">
                  <input required type="number" name="stok" class="form-control" id="stok" placeholder="10 dus" value="<?php echo $jumlah ?>">
                </div>
              </div>

              <div class="mb-3 row">
                <label for="harga" class="col-sm-2 col-form-label">Harga Barang</label>
                <div class="col-sm-10">
                  <input required type="number" name="harga" class="form-control" id="harga" placeholder="50.000" value="<?php echo $harga ?>">
                </div>
              </div>

              <div class="mb-3 row">
                <label for="tanggal" class="col-sm-2 col-form-label">Tanggal Masuk</label>
                <div class="col-sm-10">
                  <input required type="date" name="tanggal" class="form-control" id="tanggal" value="<?php echo $tanggal?>">
                </div>
              </div>
            

              <div class="mb-3 row">
                <div class="col-sm-10 offset-sm-2">
                  <?php
                    if(isset($_GET['ubah'])){
                  ?>
                    <button type="submit" name="aksi" value="edit" class="btn btn-primary">Simpan Perubahan</button>
                  <?php
                    } else {
                  ?> 
                    <button type="submit" name="aksi" value="add" class="btn btn-primary">Simpan data</button>
                  <?php
                    }
                  ?>
                    <a href="index.php" class="btn btn-danger">Batal</a>
                </div>
              </div>
        </form>
      </div>
</body>
</html> 